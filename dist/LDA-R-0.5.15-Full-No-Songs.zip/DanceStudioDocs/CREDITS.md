# Native integration references

- CommonLibSSE-NG: https://github.com/alandtse/CommonLibSSE-NG (COPYING/EXCEPTIONS included; matching SE-only SDK source included in Source ZIP).
- SKSE: https://skse.silverlock.org/ ; messages: https://github.com/ianpatt/skse64/blob/master/skse64/Hooks_SaveLoad.cpp
- Open Animation Replacer: https://github.com/ersh1/OpenAnimationReplacer ; public modder interface src/API/OpenAnimationReplacerAPI-Animations.h ; five-argument clip Generate ABI src/Hooks.h. Public API header copied as permitted by its modder comment.
- TDM public API: https://github.com/ersh1/TrueDirectionalMovement/blob/master/src/TrueDirectionalMovementAPI.h ; SE main-update call location src/Hooks.h.
- SmoothCam public API: https://github.com/mwilsnd/SkyrimSE-SmoothCam/blob/master/SmoothCam/include/SmoothCamAPI.h
- nlohmann/json: https://github.com/nlohmann/json (MIT).

Runtime dependencies are not redistributed. This archive includes no dance, music, or camera song packages. The data-only camera NPC derives from Skyrim.esm NordMalePreset01, with scripts, spells, perks, behavior packages and factions omitted.

- SKSE Menu Framework 3.8 public C ABI/API 1: https://github.com/QTR-Modding/SKSE-Menu-Framework-3-API ; https://github.com/QTR-Modding/SKSE-Menu-Framework-3 . Public interface declarations only; no embedded ImGui or framework implementation.
