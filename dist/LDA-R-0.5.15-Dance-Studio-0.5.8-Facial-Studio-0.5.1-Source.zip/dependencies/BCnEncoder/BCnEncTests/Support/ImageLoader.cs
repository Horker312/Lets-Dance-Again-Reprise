using System.IO;
using BCnEncoder.Shared;
using BCnEncoder.Shared.ImageFiles;
using CommunityToolkit.HighPerformance;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;

namespace BCnEncTests.Support
{
	public static class ImageLoader
	{
		public static Memory2D<ColorRgba32> TestDiffuse1 { get; } = LoadTestImage("../../../testImages/test_diffuse_1_512.jpg");
		public static Memory2D<ColorRgba32> TestBlur1 { get; } = LoadTestImage("../../../testImages/test_blur_1_512.jpg");
		public static Memory2D<ColorRgba32> TestNormal1 { get; } = LoadTestImage("../../../testImages/test_normal_1_512.jpg");
		public static Memory2D<ColorRgba32> TestHeight1 { get; } = LoadTestImage("../../../testImages/test_height_1_512.jpg");
		public static Memory2D<ColorRgba32> TestGradient1 { get; } = LoadTestImage("../../../testImages/test_gradient_1_512.jpg");

		public static Memory2D<ColorRgba32> TestTransparentSprite1 { get; } = LoadTestImage("../../../testImages/test_transparent.png");
		public static Memory2D<ColorRgba32> TestAlphaGradient1 { get; } = LoadTestImage("../../../testImages/test_alphagradient_1_512.png");
		public static Memory2D<ColorRgba32> TestAlpha1 { get; } = LoadTestImage("../../../testImages/test_alpha_1_512.png");
		public static Memory2D<ColorRgba32> TestRedGreen1 { get; } = LoadTestImage("../../../testImages/test_red_green_1_64.png");
		public static Memory2D<ColorRgba32> TestRgbHard1 { get; } = LoadTestImage("../../../testImages/test_rgb_hard_1.png");
		public static Memory2D<ColorRgba32> TestLenna { get; } = LoadTestImage("../../../testImages/test_lenna_512.png");
		public static Memory2D<ColorRgba32> TestDecodingBc5Reference { get; } = LoadTestImage("../../../testImages/decoding_dds_bc5_reference.png");

		public static Memory2D<ColorRgba32>[] TestCubemap { get; } = {
			LoadTestImage("../../../testImages/cubemap/right.png"),
			LoadTestImage("../../../testImages/cubemap/left.png"),
			LoadTestImage("../../../testImages/cubemap/top.png"),
			LoadTestImage("../../../testImages/cubemap/bottom.png"),
			LoadTestImage("../../../testImages/cubemap/back.png"),
			LoadTestImage("../../../testImages/cubemap/forward.png")
		};

		internal static Memory2D<ColorRgba32> LoadTestImage(string filename)
		{
			using var image = Image.Load<Rgba32>(filename);
			return ToMemory2D(image);
		}

		internal static Image<Rgba32> LoadTestImageSharp(string filename)
		{
			return Image.Load<Rgba32>(filename);
		}

		private static Memory2D<ColorRgba32> ToMemory2D(Image<Rgba32> image)
		{
			var pixels = new ColorRgba32[image.Width * image.Height];
			for (var y = 0; y < image.Height; y++)
				for (var x = 0; x < image.Width; x++)
				{
					var p = image[x, y];
					pixels[y * image.Width + x] = new ColorRgba32(p.R, p.G, p.B, p.A);
				}
			return new Memory2D<ColorRgba32>(pixels, image.Height, image.Width);
		}
	}

	public static class DdsLoader
	{
		public const string TestDecompressBc1Name = "../../../testImages/test_decompress_bc1.dds";
		public const string TestDecompressBc1AName = "../../../testImages/test_decompress_bc1a.dds";
		public const string TestDecompressBc7Name = "../../../testImages/test_decompress_bc7.dds";
		public const string TestDecompressBc5Name = "../../../testImages/decoding_dds_bc5.dds";
		public const string TestDecompressRgbaName = "../../../testImages/test_decompress_rgba.dds";

		public static DdsFile TestDecompressBc1 { get; } = LoadDdsFile(TestDecompressBc1Name);
		public static DdsFile TestDecompressBc1A { get; } = LoadDdsFile(TestDecompressBc1AName);
		public static DdsFile TestDecompressBc5 { get; } = LoadDdsFile(TestDecompressBc5Name);
		public static DdsFile TestDecompressBc7 { get; } = LoadDdsFile(TestDecompressBc7Name);
		public static DdsFile TestDecompressRgba { get; } = LoadDdsFile(TestDecompressRgbaName);

		internal static DdsFile LoadDdsFile(string filename)
		{
			using var fs = File.OpenRead(filename);
			return DdsFile.Load(fs);
		}
	}

	public static class KtxLoader
	{
		public static KtxFile TestDecompressBc1 { get; } = LoadKtxFile("../../../testImages/test_decompress_bc1.ktx");
		public static KtxFile TestDecompressBc1A { get; } = LoadKtxFile("../../../testImages/test_decompress_bc1a.ktx");
		public static KtxFile TestDecompressBc2 { get; } = LoadKtxFile("../../../testImages/test_decompress_bc2.ktx");
		public static KtxFile TestDecompressBc3 { get; } = LoadKtxFile("../../../testImages/test_decompress_bc3.ktx");
		public static KtxFile TestDecompressBc4Unorm { get; } = LoadKtxFile("../../../testImages/test_decompress_bc4_unorm.ktx");
		public static KtxFile TestDecompressBc5Unorm { get; } = LoadKtxFile("../../../testImages/test_decompress_bc5_unorm.ktx");
		public static KtxFile TestDecompressBc7Rgb { get; } = LoadKtxFile("../../../testImages/test_decompress_bc7_rgb.ktx");
		public static KtxFile TestDecompressBc7Types { get; } = LoadKtxFile("../../../testImages/test_decompress_bc7_types.ktx");
		public static KtxFile TestDecompressBc7Unorm { get; } = LoadKtxFile("../../../testImages/test_decompress_bc7_unorm.ktx");

		internal static KtxFile LoadKtxFile(string filename)
		{
			using var fs = File.OpenRead(filename);
			return KtxFile.Load(fs);
		}
	}
}
