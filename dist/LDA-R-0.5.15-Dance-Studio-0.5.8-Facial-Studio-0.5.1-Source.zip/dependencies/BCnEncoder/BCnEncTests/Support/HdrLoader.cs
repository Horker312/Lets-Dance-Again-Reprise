using System;
using System.Collections.Generic;
using System.Text;
using BCnEncoder.Shared;
using BCnEncoder.Shared.ImageFiles;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;

namespace BCnEncTests.Support
{
	public static class HdrLoader
	{
		public static HdrImage TestHdrKiara { get; } = HdrImage.Read("../../../testImages/test_hdr_kiara.hdr");
		public static HdrImage TestHdrProbe { get; } = HdrImage.Read("../../../testImages/test_hdr_probe.hdr");
		public static Image<Rgba32> ReferenceKiara { get; } = ImageLoader.LoadTestImageSharp("../../../testImages/test_hdr_kiara.png");
		public static DdsFile TestHdrKiaraDds { get; } =
			DdsLoader.LoadDdsFile("../../../testImages/test_hdr_kiara_bc6h.dds");
		public static KtxFile TestHdrKiaraKtx { get; } =
			KtxLoader.LoadKtxFile("../../../testImages/test_hdr_kiara_bc6h_ktx.ktx");
		
	}
}
