using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using BCnEncoder.Decoder;
using BCnEncoder.Encoder;
using BCnEncoder.Shared;
using BCnEncTests.Support;
using CommunityToolkit.HighPerformance;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;
using Xunit;

namespace BCnEncTests
{
	public class HdrImageTests
	{
		[Fact]
		public void LoadHdr()
		{
			using var stream = File.OpenRead("../../../testImages/test_hdr_kiara.hdr");
			var hdrImg = HdrImage.Read(stream);
			Assert.True(hdrImg.width > 0);
			Assert.True(hdrImg.height > 0);
			Assert.True(hdrImg.pixels.Length == hdrImg.width * hdrImg.height);
			
			var img = new Image<RgbaVector>(hdrImg.width, hdrImg.height);

			for (var y = 0; y < hdrImg.height; y++)
			{
				for (var x = 0; x < hdrImg.width; x++)
				{
					var i = y * hdrImg.width + x;
					img[x, y] = new RgbaVector(hdrImg.pixels[i].r, hdrImg.pixels[i].g, hdrImg.pixels[i].b);
				}
			}

			img.SaveAsPng("test_hdr_load.png");

			var img2 = img.CloneAs<Rgba32>();

			TestHelper.AssertImagesEqual(HdrLoader.ReferenceKiara, img2, CompressionQuality.BestQuality);
		}

		[Fact]
		public async Task DecodeAllMipMapsHdrStreamAsync()
		{
			var encoder = new BcEncoder();
			encoder.OutputOptions.Format = CompressionFormat.Bc6U;
			encoder.OutputOptions.Quality = CompressionQuality.Fast;
			encoder.OutputOptions.GenerateMipMaps = true;

			var decoder = new BcDecoder();
			var input = HdrLoader.TestHdrKiara;
			var ktxWithMips = encoder.EncodeToKtxHdr(new Memory2D<ColorRgbFloat>(input.pixels, input.height, input.width));
			using var ms = new MemoryStream();
			ktxWithMips.Write(ms);
			ms.Position = 0;

			var images = await decoder.DecodeAllMipMapsHdr2DAsync(ms);
			Assert.Equal((int)ktxWithMips.header.NumberOfMipmapLevels, images.Length);
			Assert.True(images.Length > 1);
		}
	}
}
