# XWM 외부 변환기

FFmpeg 실행 파일은 배포본에 포함하지 않습니다. XWM 디코딩을 지원하는 Windows FFmpeg를 설치하고 다음 중 하나로 지정하세요.

1. DanceStudio.exe 옆의 Tools/ffmpeg.exe에 배치합니다. ZIP 기준 Tools/DanceStudio/Tools/ffmpeg.exe입니다.
2. DANCESTUDIO_FFMPEG 환경 변수에 ffmpeg.exe의 절대 경로를 지정합니다.
3. PATH에서 ffmpeg.exe를 찾을 수 있도록 설치합니다.

WAV는 변환기 없이 동작합니다. 변환기 미설치·미지원 코덱·손상 데이터는 오류로 표시합니다. 확장자만 WAV로 바꾸지는 않습니다. 실제 XWM 디코딩 테스트는 이번 빌드 환경에서 수행하지 못했습니다.

공식 XWMA 구현: https://github.com/FFmpeg/FFmpeg/blob/master/libavformat/xwma.c
공식 배포/라이선스: https://ffmpeg.org/legal.html

FFmpeg는 빌드 옵션에 따라 LGPL/GPL 등의 조건이 달라집니다. 본 편집기는 별도 실행 파일을 호출하며 FFmpeg 코드나 바이너리를 포함하지 않습니다.
